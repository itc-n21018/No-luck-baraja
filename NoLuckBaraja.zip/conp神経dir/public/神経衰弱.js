let socket = io();

//音のID取得
let btn = document.getElementById('btn_audio')//カードめくる
btn.volume = 1.0
let btn2 = document.getElementById('btn_audio2')//揃えた時
btn2.volume = 0.4
let btn3 = document.getElementById('btn_audio3')//bgm
btn3.volume = 0.6
let btn4 = document.getElementById('btn_audio4')//カウントダウン
btn4.volume = 0.3
let btn5 = document.getElementById('btn_audio5')//ランキング
let btn6 = document.getElementById('btn_audio6')//確定
btn6.volume = 0.6
let btn7 = document.getElementById('btn_audio7')//間違えた時
//チャット
let a = document.getElementById("subb")
let b = document.getElementById("tex")
let c = document.getElementById("tlog")

subb.addEventListener('click', function () {
    console.log(b.value)
    socket.emit('chat', b.value)

}, false);
socket.on('chat', function (ch) {
    text = document.createElement("p")
    text.innerHTML = ch
    c.appendChild(text)
    b.value = ""
    console.log('クリックされました！');
});

//プレイヤーの数をconsole.logする　後で使う
let cone = [];
let matching = document.getElementById("match");
socket.on('c', function (co) {
    cone.push(co)
    console.log(cone.slice(-1)[0])
    matching.innerHTML = "マッチング数:" + co + "人"
    //btn6.play()//マッチング中
    if (co == 5) {
        ss();
        start();
        button.remove();
        match.remove();
    }
})
/*var video = document.getElementById('video');
if(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
navigator.mediaDevices.getUserMedia({ video: true }).then(function(stream) {//navigator.mediaDevices.getUserMedia({ video: true })これはブラウザにカメラの許可を求めるやつ
video.srcObject = stream;//　emitで送る情報これ？
video.play();   //soceket.onで受け取って実行するの多分これ
});
}*/
//ランダム関数
function rand(min, max) {
    return Math.floor(Math.random() * (max - min))
}

//経過秒数関数
let idco = document.getElementById("count");
let count = 0;
let stc = 10;
const countUp = () => {
    co = count++;
    idco.innerHTML = "経過秒数：" + count + "秒";
};
function startTimer() {
    setcount = setInterval(countUp, 1000);
};
function st() {
    idco.innerHTML = "スタート!";
}

const countdown = () => {
    cotwo = stc--;
    idco.innerHTML = "10秒間記憶してください!  " + stc;
    if (stc === 1) {
        clearInterval(downcount);
    }
};
function downTimer() {
    downcount = setInterval(countdown, 1000);
};
//スタートボタンを押すと発火
let ss = function () {
    downTimer()
    setTimeout(st, 10000);
    setTimeout(startTimer, 12000);
    btn.play()
}
let button = document.getElementById("mybutton")//スタートボタンを押したときの処理
button.addEventListener('click', () => {
    let gamestart = "ss_and_start"
    socket.emit('start', gamestart);
    //btn3.play()
    //btn3.loop = true;
})

let cards = [
    "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K",
    "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K",
    //"A", "2", "3",
    //"A", "2", "3",
];

for (let i = cards.length - 1; i > 0; i--) {
    let r = rand(0, i); //cardsと同じ数の
    let tmp = cards[i];
    cards[i] = cards[r];
    cards[r] = tmp;
}
let field = document.getElementById("field");
let start = function () {//スタートボタンを押すと発火 socekt.onで実行する？？
    for (let i = 0; i < cards.length; i++) {
        let elm = document.createElement("div");
        elm.className = "card";
        elm.id = cards[i];
        elm.innerHTML = cards[i];
        //for (let a = elm.id; a ==)
        // console.log(elm.textContent)
        setTimeout(() => elm.innerHTML = "", 12000);
        setTimeout(() => elm.className = "back", 12000)
        elm.index = i;
        setTimeout(() => elm.onclick = click, 12000);
        field.appendChild(elm);
    };

    let first = null;
    let second = null;
    let timer = null;

    //クリックされた時の処理
    function click(e) {
        if (timer) {
            clearTimeout(timer);
            judge();
        }
        let elm = e.target; //押したものを判断できる
        elm.innerHTML = cards[elm.index];

        if (!first) {
            first = elm;
            first.className = 'card'
            btn.currentTime = 0;
            btn.play()

        }
        else if (first.index === elm.index) {
            btn2.currentTime = 0;
            btn2.play()
            return;
        }
        else {
            console.log('else')
            second = elm;
            second.className = 'card'
            btn.currentTime = 0;
            btn.play()
            timer = setTimeout(judge, 1000);
            count + 5;
        }
    }
    //ジャッジする関数
    let pear = document.getElementById("pear")
    let pearcount = 13;
    function judge() {
        if (first.innerHTML === second.innerHTML) {//２つのカードの数字が同じだった場合
            first.style.visibility = "hidden";
            second.style.visibility = "hidden"       //field.removeChild(card);
            //lastcount.innerHTML = msg;hidden";
            btn2.currentTime = 0;
            btn2.play()
            const countUpPer = () => {
                pearcount--;
                pear.innerHTML = "残り" + pearcount + "ペア！";
                console.log(pearcount)
            };

            countUpPer()//終了時の関数
            if (pearcount === 0) {
                pear.innerHTML = ("結果発表までしばらくおまちください・・・")
                clearInterval(setcount);
                socket.emit("event", count);
            } else if (pearcount === 5) {
                btn3.pause();
                btn6.play()
                btn6.loop = true
                pear.style.background = 'blue'
                pear.style.animation = 'rainbow 3s infinite'
                idco.style.animation = 'rainbow 3s linear infinite'
            }
        } else {//２つのカードが別の数字だった場合の処理
            first.innerHTML = "";
            second.innerHTML = "";
            first.className = "back"
            second.className = "back"
            btn7.currentTime = 0;
            btn7.play()
            count = count + 5
        }
        first = null;
        second = null;
        timer = null;
    }
};

socket.on('start', function () {//最初にコネクト（サーバーにアクセスした人）しか実行できないようにする
    ss();
    start();
    btn4.play()
    btn3.play()
    btn3.loop = true;
    button.remove();
    match.remove()
    //socket.emit('reset')
});
function compareFunc(o, t) {
    return o - t;
}
let rankings = document.getElementById("ranking");
let rank = [];
socket.on('event', function (msg) {
    rank.push(msg)
    rank.sort(compareFunc);

    function myfunc1() {
        idco.remove()
        pear.remove()
        field.remove()

        for (i = 0; i < cone.slice(-1)[0]; i++) {
            var myp = document.createElement("p");
            myp.className = "hare"
            myp.innerHTML = (i + 1) + "位" + rank[i] + "秒"
            rankings.appendChild(myp);
        }

    }
    function keeka() {
        for (i = 0; i < cone.slice(-1)[0]; i++) {
            if (rank[i] == count) {                     //rankに何個か要素が入ればこの処理をする　後からやること
                let myrank = document.createElement("p");
                myrank.innerHTML = "あなたは" + (i + 1) + "位です!";
                rankings.appendChild(myrank)
            };
        }
    }
    if (rank.length == cone.slice(-1)[0]) { //rank.length=="2"の部分をプレイヤーの数に応じて変わるようにする
        //pear.innerHTML = ("結果発表までしばらくおまちください・・・")
        //btn6.pause();
        btn6.pause()
        btn5.play()
        setTimeout(myfunc1, 2400)
        setTimeout(keeka, 2400)
        let reloadbutton = document.createElement("div");
        reloadbutton.innerHTML = "<button><a id='reload' href='神経衰弱.html'>もう一度遊ぶ</a></button>"
        rankings.appendChild(reloadbutton);
        socket.disconnect()
    };
})
