'use strict';
const express = require('express');
const http = require('http');

// Socket.ioをインポート
const socketIo = require('socket.io');

const app = express();
const server = http.Server(app);

// 初期化
const io = socketIo(server);

const PORT = 3000;

/*app.get('/', (req, res) => {
  res.sendFile(__dirname + '/csshinkei.html');
});
​
app.use( express.static(__dirname + '/conp神経dir'));
​
server.listen(PORT, () => {
  console.log(`listening on port ${PORT}`);
});*/

// クライアントとのコネクションが確立したら'connected'という表示させる
/*io.on('connection', (socket) => {
  console.log('connected');
});*/
let conectcount = 0;
io.on('connection', function(socket){
  conectcount++;
  if(conectcount==4){
    conectcount = 0;
  }
  console.log('connected+++')
  socket.on('start',function(){
        io.emit('start');
  });
  console.log("アクセス数"+conectcount)
  io.emit('c', conectcount);
  socket.on('event', function(count){
      io.emit('event', count);
  });
  socket.on('chat', function(c){
    socket.emit('chat',c)
    console.log(c)
  })

  socket.on('disconnect',() =>{
    conectcount--;
    console.log( 'disconnect' );
} );
});
/*io.on('disconnect',() =>{
      conectcount--;
      console.log( 'disconnect' );
  } );*/
/*io.on('event', (message) => {
  console.log(message);
});*/
app.use(express.static(__dirname + '/public'));


server.listen(PORT, () => {
  console.log(`listening on port ${PORT}`);
});















